#ifndef __UT_LOG_HPP__
#define __UT_LOG_HPP__

#include <unitree/common/log/log_initor.hpp>

#endif//__UT_LOG_HPP__
